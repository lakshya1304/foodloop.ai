import { PrismaClient } from '@prisma/client';
import { ProductionRepository } from '../repositories/production.repository';
import { ProdInput, ConsInput } from '../schemas/production.schema';
import { io } from '../socket';

const prisma = new PrismaClient();
const prodRepo = new ProductionRepository();

export class ProductionService {
  async recordProduction(user: any, input: ProdInput) {
    if (!user.organizationId) throw new Error('Kitchen not found');
    const kitchen = await prisma.kitchen.findFirst({ where: { organizationId: user.organizationId }});
    if (!kitchen) throw new Error('Kitchen not found');

    return prodRepo.recordProduction(kitchen.id, input.foodItem, input.quantityProduced, input.unit);
  }

  async consumeAndCalculateSurplus(user: any, input: ConsInput) {
    if (!user.organizationId) throw new Error('Kitchen not found');
    const kitchen = await prisma.kitchen.findFirst({ where: { organizationId: user.organizationId }});
    if (!kitchen) throw new Error('Kitchen not found');

    const result = await prodRepo.consumeAndCalculateSurplus(kitchen.id, input.foodItem, input.quantityConsumed, input.unit);
    
    // Broadcast live event to NGOs and Admins if there is surplus
    if (result && result.surplus && result.surplus.quantitySurplus > 0 && io) {
      const org = await prisma.organization.findUnique({ where: { id: user.organizationId } });
      io.emit('new-surplus', {
        message: `${result.surplus.quantitySurplus}${result.surplus.unit} of ${result.surplus.foodItem} is available from ${org?.name || 'a kitchen'}!` 
      });
      io.to('role_ADMIN').emit('notification', { 
        title: 'System Activity', 
        message: `Surplus recorded at ${org?.name || 'a kitchen'}` 
      });
      io.emit('surplus_updated');
    }
    
    return result;
  }
}
