from paddleocr import PaddleOCR
import os
import numpy as np

class OcrEngine:
    def __init__(self):
        self.ocr = None
        self.lang = os.getenv("OCR_LANG", "en")
        self.use_gpu = os.getenv("OCR_DEVICE", "cpu").lower() == "gpu"
        self._is_ready = False

    def initialize(self):
        # use_angle_cls=True to automatically rotate images if needed
        self.ocr = PaddleOCR(use_angle_cls=True, lang=self.lang, use_gpu=self.use_gpu)
        self._is_ready = True

    def is_ready(self):
        return self._is_ready

    def extract_text(self, image):
        if not self._is_ready:
            raise Exception("OCR Engine not initialized")
        
        img_array = np.array(image)
        result = self.ocr.ocr(img_array, cls=True)
        
        lines = []
        if result and result[0]:
            for line in result[0]:
                bbox, (text, confidence) = line
                lines.append({
                    "text": text,
                    "confidence": confidence,
                    "bbox": bbox
                })
        return lines

ocr_engine = OcrEngine()
