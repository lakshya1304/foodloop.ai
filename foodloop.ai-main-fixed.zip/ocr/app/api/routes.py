from fastapi import APIRouter, File, UploadFile, Depends, HTTPException, Header, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List
import io
import time
from PIL import Image
from app.ocr.engine import ocr_engine
from app.ocr.field_extractor import extract_fields
import os
import uuid
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

API_KEY = os.getenv("OCR_SERVICE_API_KEY", "dev_ocr_secret_key_123")
MAX_FILE_SIZE = int(os.getenv("OCR_MAX_FILE_SIZE_MB", "10")) * 1024 * 1024

def verify_api_key(x_ocr_service_key: str = Header(None)):
    if not x_ocr_service_key or x_ocr_service_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

@router.get("/health")
def health_check():
    return {"status": "ok", "service": "ocr", "device": os.getenv("OCR_DEVICE", "cpu")}

@router.get("/ready")
def ready_check():
    if ocr_engine.is_ready():
        return {"status": "ready"}
    return JSONResponse(status_code=503, content={"status": "not_ready"})

@router.post("/v1/ocr/extract-label")
async def extract_label(
    file: UploadFile = File(...),
    _ = Depends(verify_api_key)
):
    request_id = str(uuid.uuid4())
    start_time = time.time()
    
    try:
        content = await file.read()
        if len(content) > MAX_FILE_SIZE:
            return JSONResponse(status_code=413, content={"success": False, "error": {"code": "OCR_FILE_TOO_LARGE", "message": "File too large"}, "request_id": request_id})
        
        try:
            image = Image.open(io.BytesIO(content)).convert("RGB")
        except Exception as e:
            return JSONResponse(status_code=400, content={"success": False, "error": {"code": "OCR_INVALID_IMAGE", "message": "Unsupported or invalid image."}, "request_id": request_id})
        
        # Simple extraction
        raw_lines = ocr_engine.extract_text(image)
        
        # Process lines
        text_lines = []
        confidences = []
        for line in raw_lines:
            text_lines.append(line['text'])
            confidences.append(line['confidence'])
        
        raw_text = "\n".join(text_lines)
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        # Extract structured fields
        extracted = extract_fields(text_lines)
        
        data = {
            "product_name": extracted.get("product_name"),
            "manufacturing_date": extracted.get("manufacturing_date"),
            "expiry_date": extracted.get("expiry_date"),
            "batch_number": extracted.get("batch_number"),
            "confidence": avg_confidence,
            "field_confidence": {
                "product_name": avg_confidence if extracted.get("product_name") else 0.0,
                "manufacturing_date": avg_confidence if extracted.get("manufacturing_date") else 0.0,
                "expiry_date": avg_confidence if extracted.get("expiry_date") else 0.0,
                "batch_number": avg_confidence if extracted.get("batch_number") else 0.0,
            },
            "raw_text": raw_text,
            "normalized_text": raw_text,
            "warnings": extracted.get("warnings", [])
        }
        
        processing_ms = int((time.time() - start_time) * 1000)
        
        return {
            "success": True,
            "request_id": request_id,
            "processing_ms": processing_ms,
            "data": data
        }
        
    except Exception as e:
        logger.error(f"[{request_id}] OCR Failed: {e}")
        return JSONResponse(status_code=500, content={"success": False, "error": {"code": "OCR_INTERNAL_ERROR", "message": str(e)}, "request_id": request_id})
