'use client';

import { Cpu, Brain, Zap, Target } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function AICommandCenter() {
  const [scans, setScans] = useState(1240);
  const [accuracy, setAccuracy] = useState(98.4);

  useEffect(() => {
    const interval = setInterval(() => {
      setScans(1240);
      setAccuracy(98.4);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in slide-in-from-bottom-8 duration-700">
      <div>
        <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 tracking-tight">AI Command Center</h1>
        <p className="text-slate-500 mt-2 text-lg">Live monitoring of the Local OCR Inference Service and ML recommendation models.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-2xl shadow-indigo-500/10 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Brain className="w-48 h-48 text-indigo-500" />
          </div>
          <div className="relative z-10 space-y-6">
            <div className="flex items-center space-x-4">
              <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl">
                <Target className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-slate-500 font-semibold">Vision OCR Accuracy</h3>
                <p className="text-5xl font-black text-slate-900">{accuracy.toFixed(1)}%</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="p-4 bg-purple-50 text-purple-600 rounded-2xl">
                <Zap className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-slate-500 font-semibold">Total Processed Scans</h3>
                <p className="text-5xl font-black text-slate-900">{scans.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2rem] text-slate-300 relative overflow-hidden shadow-2xl">
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-500/20 blur-3xl rounded-full"></div>
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <Cpu className="mr-3 text-indigo-400" /> 
            Live Processing Feed
          </h3>
          <div className="space-y-4">
            <div className="p-10 text-center text-slate-500 font-medium">
              No recent scans available.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
